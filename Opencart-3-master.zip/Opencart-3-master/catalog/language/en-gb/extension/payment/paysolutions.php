<?php
$_['heading_title']				= 'Your order has been placed!';
$_['text_title']				= 'Credit / Debit Card Payment (Paysolutions)';
$_['text_instruction']			= 'Pay through Paysolutions';
$_['text_payable']				= 'Make Payable To: ';
$_['text_address']				= 'Send To: ';
$_['text_payment']				= 'Your order will not ship until we receive payment.';
$_['url']	= 'https://www.thaiepay.com/epaylink/payment.aspx';

