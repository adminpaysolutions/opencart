<?php
// Text
$_['text_title'] = 'Paysolutions';

$_['heading_title00'] = 'Recive payment form Paysolutions';
$_['heading_title01'] = 'Some problem from Paysolutions';
$_['heading_title99'] = 'Error form Paysolutions';

$_['text_message00'] = 'Thank a lot from payment by Paysolutions';
$_['text_message01'] = 'Have Some problem from Paysolutions';
$_['text_message99'] = 'Alert Error from Paysolutions';

$_['text_pay_code'] = 'Code of Paysolutions : ';
$_['text_pay_amt'] = 'Paymet from Paysolutions : ';



$_['text_pay_method'] = 'Method Paysolutions : ';

$_['text_pay_error'] = 'Order to complete the transaction to the press, then make payment.!';
$_['text_pay_comp'] = 'The order is complete, press the button to continue to purchase a complete';

?>