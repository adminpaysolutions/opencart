<?php
// Heading
$_['heading_title']      = 'Paysolutions';

// Text 
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Paysolutions account details!';
$_['text_paysolutions']   = '<a onclick="window.open(\'https://www.thaiepay.com/\');">
<img src="view/image/payment/paysolutions.gif" alt="Paysolutions" title="Paysolutions" style="border: 1px solid #EEEEEE;" /></a>';

$_['text_sale']          = 'Payment';

// Entry
$_['entry_email']        = 'E-Mail:';
$_['entry_transaction']  = 'MerchantID:';

$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

$_['text_pay_comp']	     = 'Complete for payment';

$_['entry_updatestatus'] = 'Update Status Payment';
// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Paysolutions!';
$_['error_email']        = 'E-Mail required!'; 
?>