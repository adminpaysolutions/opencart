<?php
// Heading
$_['heading_title']      = 'เพย์โซลูชั่น';

// Text 
$_['text_payment']       = 'ชำระเงิน';
$_['text_success']       = 'สำเร็จ: คุณแก้ไข การชำระแบบ เพย์โซลูชั่น แล้ว!';
$_['text_paysolutions']   = '<a onclick="window.open(\'https://www.thaiepay.com/\');">
<img src="view/image/payment/paysolutions.gif" alt="Paysolutions" title="Paysolutions" style="border: 1px solid #EEEEEE;" /></a>';

$_['text_sale']          = 'ชำระเงิน';

// Entry
$_['entry_email']        = 'อีเมล์ของบัญชี:';
$_['entry_transaction']  = 'MerchantID:';

$_['entry_status']       = 'สถานะ:';
$_['entry_sort_order']   = 'ลำดับการแสดง:';

$_['text_pay_comp']	     = 'ชำระเงินเรียบร้อยแล้ว';

$_['entry_updatestatus'] = 'ปรับปรุงสถานะการชำระเงิน';
// Error
$_['error_permission']   = 'คำเตือน:คุณไม่ได้รับอนุญาติเข้าใช้ เพย์โซลูชั่น!';
$_['error_email']        = 'จำเป็นต้องใส่อีเมล์!'; 
?>